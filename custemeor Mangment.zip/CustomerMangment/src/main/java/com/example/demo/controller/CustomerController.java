package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.service.CusotmerService;

@RestController
public class CustomerController {

	@Autowired
	@Qualifier("premiumCustomerServiceImpl")
	CusotmerService cusotmerServicePre;
	
	
	
	@Autowired
	@Qualifier("normalCustomerSericeImpl")
	CusotmerService cusotmerServiceNormal;
	
	
	@PostMapping("customer")
	public String saveCUstomer(@RequestBody Customer customer)
	{
		
		if(customer.getType().equals("premium"))
		return	cusotmerServicePre.saveCustomer(customer);
		
		if(customer.getType().equals("normal"))
		return	cusotmerServiceNormal.saveCustomer(customer);
		
	return	"invalid customer";

	}
	
}
