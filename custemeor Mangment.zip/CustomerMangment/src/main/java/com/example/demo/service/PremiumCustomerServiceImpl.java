package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.repo.CustomerRepo;

@Service
public class PremiumCustomerServiceImpl implements CusotmerService {

	@Autowired
	CustomerRepo customerRepo;
	
	@Override
	public String saveCustomer(Customer customer) {

		if (customer.getPoints() > 500) {

			int points = customer.getPoints();
			customer.setPoints(points + 500);
			customerRepo.save(customer);
			
			return "premium customer added with bouns";
		}
		return "this customer is not premium so cant save";
		

	}

}
