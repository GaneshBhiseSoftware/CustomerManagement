package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.repo.CustomerRepo;
@Service
public class NormalCustomerSericeImpl implements CusotmerService {

	@Autowired
	CustomerRepo customerRepo;
	
	@Override
	public String saveCustomer(Customer customer) {
		
		
		customerRepo.save(customer);
		
		return "normal customer saved";
		// TODO Auto-generated method stub
		
	}

}
