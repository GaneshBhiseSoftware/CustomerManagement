package com.example.demo.service;

import com.example.demo.entity.Customer;

public interface CusotmerService {
public String saveCustomer(Customer customer);
	
	
}
